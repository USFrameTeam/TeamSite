### UnknowServerFramework(USF V3)

基于原版MinecraftBedrockEdition ScriptAPI

这是一个V3的分支，重写了部分功能，功能不全，目前还有亿堆bug

日志服务器安装
	将日志服务器放在mc服务端执行程序目录
```
		服务器目录
		    └───── bedrock_server
		    		 ├───server.properties
		    		 ├───config.json
		    		 └───usf_manager.jar
```
 运行
```
java -jar usf_manager.jar
```
